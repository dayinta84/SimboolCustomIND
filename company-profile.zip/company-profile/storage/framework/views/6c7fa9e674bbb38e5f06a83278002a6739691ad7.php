

<?php $__env->startSection('content'); ?>

<style>
    h3.text-center.mb-4.fw-bold {
        color: white;
        font-weight: 800;
        letter-spacing: 1px;
    }

    .product-card {
        background: rgba(0,0,0,0.12);
        backdrop-filter: blur(4px);
        border: 1px solid rgba(255,255,255,0.2); /* GARIS PUTIH TIPIS */
        border-radius: 16px;
        overflow: hidden;
        transition: .25s ease;
    }

    .product-card:hover {
        background: rgba(0,0,0,0.20);
        transform: translateY(-4px);
        box-shadow: 0 8px 20px rgba(0,0,0,.15);
    }

    .card-img-top {
        height: 180px;
        object-fit: cover;
    }

    /* TEXT PUTIH */
    .product-name {
        font-size: 14px;
        font-weight: 600;
        color: #ffffff;
    }

    .product-category {
        font-size: 11px;
        color: #e2e2e2;
    }

    /* BUTTON PUTIH */
    .btn-detail {
        font-size: 11px;
        padding: 5px 12px;
        border-radius: 8px;
        color: #ffffff;
        border: 1px solid rgba(255,255,255,0.5);
        background: transparent;
    }

    .btn-detail:hover {
        background: rgba(255,255,255,0.15);
        color: #ffffff;
        border-color: #ffffff;
    }

    /* BADGE FILTER (All & Kategori) */
    .category-pill {
        font-size: 12px;
        font-weight: 500;
        padding: 5px 12px;
        transition: all 0.2s ease;
    }

    .category-pill.bg-primary {
        background: #7D3C98 !important;
        color: white !important;
        border: none;
    }

    .category-pill.bg-light {
        background: rgba(255,255,255,0.15) !important;
        color: white !important;
        border: 1px solid rgba(255,255,255,0.3);
    }

    .category-pill:hover {
        transform: scale(1.05);
    }
</style>


<div class="container py-4">

    <h3 class="text-center mb-4 fw-bold">TEMUKAN SOLUSI CETAKMU</h3>

    
    <?php
    $active = request('category');
?>

<div class="text-center mb-4">
    <a href="<?php echo e(route('products.index')); ?>"
       class="badge category-pill rounded-pill px-3 py-2 mx-1
       <?php echo e($active ? 'bg-light text-dark' : 'bg-primary text-white border-0'); ?>">
        All
    </a>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('products.index', ['category' => $cat])); ?>"
           class="badge category-pill rounded-pill px-3 py-2 mx-1
           <?php echo e($active === $cat ? 'bg-primary text-white border-0' : 'bg-light text-dark'); ?>">
            <?php echo e($cat); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



    
    <div class="row g-3">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-6 col-md-3">
                <div class="card product-card shadow-sm h-100">

                    
                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset('storage/'.$product->image)); ?>"
                             class="card-img-top">
                    <?php else: ?>
                        <div class="bg-light d-flex align-items-center justify-content-center"
                             style="height:180px;">
                            <span class="text-muted small">No Image</span>
                        </div>
                    <?php endif; ?>

                    
                    <div class="card-body text-center p-2">

                        
                        <h6 class="product-name text-uppercase mb-1">
                            <?php echo e($product->name); ?>

                        </h6>

                        
                        <small class="product-category d-block mb-1">
                            <?php echo e($product->category); ?>

                        </small>

                        
                        <a href="<?php echo e(route('products.show', $product->id)); ?>"
                        class="btn-detail mt-1 d-inline-block">
                            Detail
                        </a>

                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5 text-muted">
                Tidak ada produk untuk kategori ini.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyek TI\Company Profile\ProyekSimbool\SimboolCustomIND\company-profile\resources\views/visit/products.blade.php ENDPATH**/ ?>