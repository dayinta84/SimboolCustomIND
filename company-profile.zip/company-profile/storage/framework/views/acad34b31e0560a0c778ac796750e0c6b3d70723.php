

<?php $__env->startSection('content'); ?>

<?php
    $role = Auth::user()->role;
?>

<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-dark">
            <i class="fas fa-home me-2 text-muted"></i> Edit Halaman Depan
        </h2>
        <a href="<?php echo e(route('home')); ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-eye me-1"></i> Preview
        </a>
    </div>

    <!-- ======================= SLIDER ======================= -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-light py-2">
            <h5 class="mb-0 fw-bold text-dark">
                <i class="fas fa-images me-2 text-primary"></i> Slider
            </h5>
        </div>
        <div class="card-body">

            <form action="<?php echo e(route('admin.slider.store', ['role' => $role])); ?>" method="POST" enctype="multipart/form-data" class="mb-3">
                <?php echo csrf_field(); ?>
                <div class="row g-2 align-items-end">
                    <div class="col-md-6">
                        <label class="form-label fw-medium text-dark">Upload Gambar</label>
                        <input type="file" name="image" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-plus me-1"></i> Tambah Slider
                        </button>
                    </div>
                </div>
            </form>

            <?php if($slides->count()): ?>
                <div class="row g-3 mt-1">
                    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="card h-100 shadow-sm border">
                                <img src="<?php echo e(asset('storage/'.$slide->image)); ?>" 
                                     class="card-img-top" 
                                     alt="Slider"
                                     style="height: 140px; object-fit: cover;">
                                <div class="card-body p-2">
                                    <p class="text-muted small mb-1"><?php echo e(Str::limit($slide->title ?? '—', 25)); ?></p>
                                </div>
                                <div class="card-footer bg-white p-2 border-top">
                                    <form action="<?php echo e(route('admin.slider.delete', ['role' => $role, 'id' => $slide->id])); ?>" method="POST" class="d-grid">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" 
                                                class="btn btn-outline-danger btn-sm"
                                                onclick="return confirm('Yakin hapus slider ini?')">
                                            <i class="fas fa-trash-alt me-1"></i> Hapus
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="alert alert-light text-center border mb-0">
                    <i class="fas fa-info-circle text-muted me-1"></i> Belum ada slider.
                </div>
            <?php endif; ?>

        </div>
    </div>

    <hr class="my-4">

    <!-- ======================= KONTEN UTAMA ======================= -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-light py-2">
            <h5 class="mb-0 fw-bold text-dark">
                <i class="fas fa-heading me-2 text-info"></i> Konten Utama
            </h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.home_content.update', $role)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label fw-medium">Judul Halaman</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e($content->title ?? ''); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-medium">Sub Judul</label>
                        <input type="text" name="subtitle" class="form-control" value="<?php echo e($content->subtitle ?? ''); ?>">
                    </div>
                    <div class="col-12 text-end">
                        <button type="submit" class="btn btn-success px-4">
                            <i class="fas fa-save me-1"></i> Simpan Konten Utama
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <hr class="my-4">

    <!-- ======================= MENGAPA KAMI (WHY) ======================= -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-light py-2 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold text-dark">
                <i class="fas fa-question-circle me-2 text-purple"></i> Mengapa Kami
            </h5>
            <button class="btn btn-sm btn-outline-purple" data-bs-toggle="collapse" data-bs-target="#addWhyForm">
                <i class="fas fa-plus me-1"></i> Tambah
            </button>
        </div>
        <div class="card-body">

            <!-- Form Tambah (dengan collapse agar rapi) -->
            <div class="collapse <?php echo e($errors->has('title') ? 'show' : ''); ?>" id="addWhyForm">
                <form action="<?php echo e(route('admin.why.store', $role)); ?>" method="POST" class="mb-4 p-3 bg-light rounded">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-md-5">
                            <label class="form-label fw-medium">Judul</label>
                            <input type="text" name="title" class="form-control" placeholder="Contoh: Tim Profesional" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-medium">Deskripsi</label>
                            <textarea name="description" class="form-control" rows="2" placeholder="Penjelasan singkat..." required></textarea>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-purple w-100">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Tabel WHY -->
            <?php if($whys->count()): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 5%;">#</th>
                                <th>Judul</th>
                                <th>Deskripsi</th>
                                <th style="width: 15%;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $whys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $why): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="fw-bold text-muted"><?php echo e($index + 1); ?></td>
                                    <td><strong><?php echo e($why->title); ?></strong></td>
                                    <td class="text-muted"><?php echo e(Str::limit($why->description, 60)); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-warning me-1"
                                            onclick="openWhyEdit('<?php echo e($why->id); ?>', '<?php echo e(addslashes($why->title)); ?>', '<?php echo e(addslashes($why->description)); ?>')">
                                            <i class="fas fa-edit"></i>
                                        </button>

                                        <form action="<?php echo e(route('admin.why.delete', ['role'=>$role, 'id'=>$why->id])); ?>"
                                              method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-danger" type="submit">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-exclamation-circle fa-2x mb-2"></i>
                    <p class="mb-0">Belum ada poin "Mengapa Kami".</p>
                </div>
            <?php endif; ?>

            <!-- Form Edit (tetap hidden, hanya tampilan diperbaiki) -->
            <div id="editWhyBox" class="mt-4 p-4 border rounded bg-light" style="display:none;">
                <h5 class="fw-bold text-dark mb-3">
                    <i class="fas fa-edit me-2 text-warning"></i> Edit Poin "Mengapa Kami"
                </h5>
                <form id="editWhyForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label fw-medium">Judul</label>
                            <input type="text" name="title" id="why_title" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-medium">Deskripsi</label>
                            <textarea name="description" id="why_desc" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-12 text-end">
                            <button type="button" class="btn btn-secondary me-2" onclick="document.getElementById('editWhyBox').style.display='none'">
                                Batal
                            </button>
                            <button type="submit" class="btn btn-warning">
                                <i class="fas fa-save me-1"></i> Update
                            </button>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.text-purple { color: #7E22CE !important; }
.btn-purple {
    background-color: #7E22CE;
    border-color: #7E22CE;
    color: white;
}
.btn-purple:hover {
    background-color: #6B21A8;
    border-color: #581C87;
}
.btn-outline-purple {
    color: #7E22CE;
    border-color: #7E22CE;
}
.btn-outline-purple:hover {
    background-color: #f5f3ff;
    color: #581C87;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
function openWhyEdit(id, title, description) {
    document.getElementById("editWhyBox").style.display = "block";
    document.getElementById("why_title").value = title;
    document.getElementById("why_desc").value = description;
    document.getElementById("editWhyForm").action = "/<?php echo e($role); ?>/home_content/why/update/" + id;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyek TI\Company Profile\ProyekSimbool\SimboolCustomIND\company-profile\resources\views/dashboardadmin/home_content/edit.blade.php ENDPATH**/ ?>