

<?php $__env->startSection('content'); ?>

<style>
    .market-card {
        width: 80%;
        max-width: 420px;
        padding: 25px;
        border-radius: 18px;
        border: 1px solid rgba(255, 255, 255, 0.25);
        background: rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(10px);
        transition: 0.3s ease;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.35);
    }

    .market-card:hover {
        transform: translateY(-6px);
        background: rgba(255, 255, 255, 0.15);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
        border-color: rgba(255, 255, 255, 0.45);
    }

    .market-img {
        max-height: 90px;
        filter: drop-shadow(0 0 5px rgba(255,255,255,0.4));
    }

    .market-btn {
        border-radius: 10px;
        padding: 8px 20px;
        border: 1px solid rgba(255,255,255,0.6);
        transition: 0.25s;
    }

    .market-btn:hover {
        background: rgba(255,255,255,0.9);
        color: #000 !important;
    }
</style>

<div class="container py-5">
    <h2 class="text-center mb-5 fw-bold text-white">Temukan kami di Marketplace dan Sosial Media</h2>

    <div class="row justify-content-center gx-2 gy-4">
        <?php $__currentLoopData = $marketplaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-sm-12 mb-4 d-flex justify-content-center">
                
                <div class="market-card text-center text-white">

                    <?php if($market->icon): ?>
                        <img src="<?php echo e(asset('storage/' . $market->icon)); ?>" 
                             class="img-fluid mb-3 market-img"
                             alt="<?php echo e($market->platform); ?>">
                    <?php endif; ?>

                    <h5 class="fw-bold mb-1"><?php echo e($market->platform); ?></h5>

                    <?php if($market->username): ?>
                        <p class="mb-1">@ <?php echo e($market->username); ?></p>
                    <?php endif; ?>

                    <?php if($market->followers): ?>
                        <p class="small text-light mb-3"><?php echo e($market->followers); ?> Pengikut</p>
                    <?php endif; ?>

                    <?php if($market->link): ?>
                        <a href="<?php echo e($market->link); ?>" target="_blank" 
                           class="btn btn-outline-light market-btn">Kunjungi</a>
                    <?php endif; ?>

                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyek TI\Company Profile\ProyekSimbool\SimboolCustomIND\company-profile\resources\views/visit/marketplace.blade.php ENDPATH**/ ?>